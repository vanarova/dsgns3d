                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:523543
Flexible and Breathable Insole by Gyrobot is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Some example insoles to show the usefulness of [Filaflex](http://recreus.com/) within the Podiatry field.  

Sliced in [Craftware](http://www.craftunique.com/craftware) or Slic3r with zero top and bottom surfaces to give an open core mesh to aid ventilation.  

#####EDIT 10/06/2016 : Create your own insoles with my design software over at http://www.gensole.com

Video :  http://youtu.be/EtxfiqKxnBM  

http://www.gyrobot.co.uk   
http://www.facebook.com/gyrobotuk

# Instructions

Slice with zero top and bottom layers to reveal the open core mesh.  

Please see more on my blog here (specifically part 2) :  
http://www.gyrobot.co.uk/blog/my-adventures-with-3d-printed-insoles-part-1-4  
http://www.gyrobot.co.uk/blog/my-adventures-with-3d-printed-insoles-part-2-4  
http://www.gyrobot.co.uk/blog/my-adventures-with-3d-printed-insoles-part-3-4